const http = require("http"); //importing the html libary?
const fs = require('fs'); //imports the file systems handing libaray
const port = 3000;  //this is our port number, its like the radio frequency you tune into to listien to a music station
const path = require('path');  //specify the directory location
const { parse } = require('querystring');

const server = http.createServer(function(req,res)
{
    //writehead pramas (status code, different headers you want to set)
    //status code 200 means that everything went well
    //'content-type': 'text/html' tells the head that we are trying to write an html file to it
    //'content-type refers to the content that the header is going to inturpt as the formating for the file on the server?

    //req = request
    //res = response
    res.writeHead(200,{ 'Content-Type': 'text/html'});

    res.write(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <form id="myForm" onAction="localhost:3000" method="POST">
            <div>
                <label for="tAreaValue" name="tAreaLabel" id="tAreaLabel">Type something in here</label>
            </div>
            <div>
            </div>
            <div>
                <!--<input> not needed in this i dont think-->
                <textarea placeholder="type things in here" name="tAreaValue" id="tAreaValue"></textarea>
            </div>
            <div>
                <button type="submit" id="saveButton">Save</button>
            </div>
        </form>
    </body>
    </html>`)
    /*
    fs.readFile('index.html', function(error, data)
    {
        //data is a varible of all the data the is grabed from reading the file in question. in this case our index html file
        if(error) //checks if there was an error in the file reading
        {
            //status code 404 means the thing that you were trying to find could not be found
            res.writeHead(404);
            res.write("Error: File Not Found");
        }
        else
        {
            res.write(data);
        }
        res.end();
    });
    */

    if(req.method == "POST")
    {
        const chunks = [];
        let body = '';
        req.on("data", (chunk) =>
        {
            chunks.push(chunk);
            body += chunk.toString();
        });
        req.on("end", () =>
        {
            //console.log("all parts/chuncks have arrived");
            const data = Buffer.concat(chunks); //where we are going to push data onto
            console.log("data = " + data.toString());
            //the lines above gets us our post request's data in a querystring format. now we have convert the query string into an array of string pairs,
            //which represent the data we are posting through
            
            const parsedData = new URLSearchParams(data.toString);
            let dataObj = [];


            //let test2 = 
            let test = parse(body);
            console.log(parse(body));
            
            req.body = parse(body);
            console.log(req.body);


            /*
            for(var pair of parsedData.entries())
            {
                console.log(pair[0]);
                console.log(pair[2]);
                dataObj[pair[0]] = pair[1];
            }
            */
            //console.log(parsedData.entries());
            //console.log("DataObj: ", dataObj);
        });
        res.end();
        
    }
    

    //res.end();
});

server.listen(port, function(error) //this is an event that listiens for a request to connect to the server by the client
{
    if(error) //if request to the server is a failure then this is done
    {
        console.log("something went wrong", error);
    }
    else //if request to the sever is a sucess then this is done
    {
        console.log("server is listening on port " + port);
    }
})